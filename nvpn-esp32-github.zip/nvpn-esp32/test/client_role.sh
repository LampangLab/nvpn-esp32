#!/bin/bash
# Client-only role negotiation against the real nostr-vpn FIPS core (needs test/interop-rs built).
#  1. default            -> upstream answers ClientSupport  => role client-only, ping through the seed works
#  2. NVPN_NO_CLIENT=1   -> negotiation disabled           => TreeAnnounce, ping works
#  3. NVPN_NO_CLIENT=2   -> upstream "never answers"       => fallback to TreeAnnounce after one interval, ping works
cd "$(dirname "$0")"; fail=0
for case in "0|client-only" "1|fallback" "2|fallback"; do
  m=${case%%|*}; want=${case##*|}
  out=$(KEEP=1 NVPN_NO_CLIENT=$m timeout 90 ./mesh3.sh 8 2>&1)
  ps -eo pid,cmd | grep "release/echo" | grep -v grep | awk '{print $1}' | xargs -r kill 2>/dev/null; sleep 1
  role=$(echo "$out" | awk '/^ROLE:/{print $2}'); rc=$(echo "$out" | grep -c "RESULT: PING OK")
  if [ "$role" = "$want" ] && [ "$rc" = 1 ]; then echo "PASS NVPN_NO_CLIENT=$m role=$role ping=ok"; else echo "FAIL NVPN_NO_CLIENT=$m role=$role (want $want) ping_ok=$rc"; fail=1; fi
done
# 4. inbound: a Rust peer opens the session towards the client-only leaf through the seed (30 s: the peer retries)
out=$(MODE=in timeout 90 ./mesh3.sh 30 2>&1); ps -eo pid,cmd | grep "release/echo" | grep -v grep | awk '{print $1}' | xargs -r kill 2>/dev/null
if echo "$out" | grep -q "INBOUND OK" && echo "$out" | grep -q "^ROLE: client-only"; then echo "PASS inbound to client-only leaf"; else echo "FAIL inbound to client-only leaf"; fail=1; fi
exit $fail
