#!/usr/bin/env python3
"""Compute nostr-vpn mesh IPv4 addresses offline (same rule as the app / nvpn.h).

  mesh_ip.py <network_id> <npub|hex> [<npub|hex> ...]
"""
import hashlib, re, sys

CH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"

def pubkey_hex(s):
    s = s.strip()
    if re.fullmatch(r"[0-9a-fA-F]{64}", s):
        return s.lower()
    if s.startswith("npub1"):
        d = [CH.index(c) for c in s[5:-6]]
        acc = bits = 0; out = []
        for v in d:
            acc = (acc << 5) | v; bits += 5
            while bits >= 8:
                bits -= 8; out.append((acc >> bits) & 255)
        return bytes(out).hex()
    raise ValueError("bad key: " + s)

def normalize_network_id(n):
    n = n.strip()
    if n.startswith("nostr-vpn:"):
        n = n[len("nostr-vpn:"):].strip()
    if n and re.fullmatch(r"[0-9a-fA-F\s\-]+", n):
        n = re.sub(r"[\s\-]", "", n).lower()
    return n

def mesh_ip(network_id, key):
    d = hashlib.sha256((normalize_network_id(network_id) + "\n" + pubkey_hex(key)).encode()).digest()
    return f"10.44.{d[0] % 254 + 1}.{d[1] % 254 + 1}"

if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    for k in sys.argv[2:]:
        print(mesh_ip(sys.argv[1], k), k)
