#!/usr/bin/env python3
"""Extract the signed roster event for a network from nostr-vpn's signed-rosters.json and print it
as compact JSON, ready for `main/roster.json` (ESP-IDF) or ROSTER_JSON (Arduino).

  extract_roster.py <path/to/signed-rosters.json> [network_id]
Also prints the signer (admin) pubkey and the member list to stderr.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mesh_ip import mesh_ip

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    store = json.load(open(sys.argv[1]))
    rosters = store.get("rosters", {})
    if not rosters:
        sys.exit("no signed rosters in file (is the daemon running as the network admin?)")
    key = sys.argv[2] if len(sys.argv) > 2 else None
    if key is None:
        if len(rosters) > 1:
            sys.exit("several networks, pick one: " + ", ".join(rosters))
        key = next(iter(rosters))
    if key not in rosters:
        sys.exit("unknown network id; have: " + ", ".join(rosters))
    ev = rosters[key]["event"]
    print("network id :", key, file=sys.stderr)
    print("admin pubkey:", ev["pubkey"], file=sys.stderr)
    for t in ev["tags"]:
        if len(t) > 1 and t[0] in ("member", "admin"):
            print(f"{t[0]:6} {mesh_ip(key, t[1])}  {t[1]}", file=sys.stderr)
    print(json.dumps(ev, separators=(",", ":"), ensure_ascii=False))

main()
