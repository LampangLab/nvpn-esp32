#!/usr/bin/env python3
"""Test peer for the ESP32: UDP echo on :7777 and a tiny HTTP server on :8080, bound to all interfaces
(so also reachable on the PC's mesh IP 10.44.x.y once nostr-vpn is up).

  pc_echo.py [udp_port=7777] [http_port=8080]
"""
import socket, sys, threading
from http.server import BaseHTTPRequestHandler, HTTPServer

udp_port = int(sys.argv[1]) if len(sys.argv) > 1 else 7777
http_port = int(sys.argv[2]) if len(sys.argv) > 2 else 8080

def udp():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind(("0.0.0.0", udp_port))
    while True:
        data, addr = s.recvfrom(2048)
        print(f"UDP {len(data)} bytes from {addr[0]}: {data[:40]!r}", flush=True)
        s.sendto(data, addr)

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        body = b"hello from pc over nostr-vpn\n"
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers()
        self.wfile.write(body)
        print(f"HTTP GET from {self.client_address[0]}", flush=True)
    def log_message(self, *a): pass

threading.Thread(target=udp, daemon=True).start()
print(f"echo: udp/{udp_port}, http/{http_port}", flush=True)
HTTPServer(("0.0.0.0", http_port), H).serve_forever()
