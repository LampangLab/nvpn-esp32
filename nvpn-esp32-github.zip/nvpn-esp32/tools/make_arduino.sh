#!/bin/sh
# Build an Arduino-IDE-compatible library folder (library.properties + flat src/) from this repo.
# usage: tools/make_arduino.sh <out_dir>   -> <out_dir>/nvpn-esp32/
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd); OUT="$1/nvpn-esp32"; S="$OUT/src"
[ -n "$1" ] || { echo "usage: $0 <out_dir>"; exit 2; }
rm -rf "$OUT"; mkdir -p "$S/secp256k1" "$OUT/examples/FipsLeaf"
cp "$ROOT"/include/*.h "$ROOT"/src/*.h "$ROOT"/src/*.c "$ROOT"/port/*.c "$S/"
cp "$ROOT"/third_party/secp256k1/include/*.h "$S/"          # so <secp256k1.h> resolves from src/
cp -r "$ROOT"/third_party/secp256k1/include "$ROOT"/third_party/secp256k1/src "$ROOT"/third_party/secp256k1/COPYING "$S/secp256k1/"
find "$S/secp256k1" \( -name CMakeLists.txt -o -name '*.am' -o -name '*.include' -o -name 'bench*' -o -name 'tests*' \) -delete
# the three secp .c files must not be compiled directly by the Arduino builder (no per-library -D flags): wrap them
for f in secp256k1 precomputed_ecmult precomputed_ecmult_gen; do
  mv "$S/secp256k1/src/$f.c" "$S/secp256k1/src/$f.inc"
  printf '/* generated: libsecp256k1 unit with MCU configuration */\n#include "nvpn_secp_cfg.h"\n#include "secp256k1/src/%s.inc"\n' "$f" > "$S/nvpn_secp_$f.c"
done
cat > "$S/nvpn_secp_cfg.h" <<'EOC'
#ifndef NVPN_SECP_CFG_H
#define NVPN_SECP_CFG_H
#define SECP256K1_BUILD
#define ECMULT_WINDOW_SIZE 4
#define ECMULT_GEN_PREC_BITS 2
#define ENABLE_MODULE_SCHNORRSIG 1
#define ENABLE_MODULE_EXTRAKEYS 1
#define ENABLE_MODULE_ECDH 1
#define USE_EXTERNAL_DEFAULT_CALLBACKS 1
#define USE_FIELD_10X26 1
#define USE_SCALAR_8X32 1
#endif
EOC
cp "$ROOT"/examples/arduino/library.properties "$OUT/"
cp "$ROOT"/examples/arduino/FipsLeaf.ino "$OUT/examples/FipsLeaf/"; mkdir -p "$OUT/examples/SelfTest" "$OUT/examples/VirtualLan"; cp "$ROOT"/examples/arduino/SelfTest/* "$OUT/examples/SelfTest/"; cp "$ROOT"/examples/arduino/VirtualLan.ino "$OUT/examples/VirtualLan/"
mkdir -p "$OUT/tools" "$OUT/docs"; cp "$ROOT"/tools/*.py "$OUT/tools/"; cp "$ROOT"/docs/*.md "$OUT/docs/"
cp "$ROOT"/LICENSE "$ROOT"/README.md "$OUT/"
