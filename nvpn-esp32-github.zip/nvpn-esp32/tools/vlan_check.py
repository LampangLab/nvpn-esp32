#!/usr/bin/env python3
"""Run from a roster member (PC / phone-side tooling) against the ESP32's mesh IP.

  vlan_check.py <esp_mesh_ip> [udp_port=7777] [http_port=8080]
Checks: ICMP ping, UDP echo round trip (+RTT), HTTP GET. Exit code 0 only if all pass.
"""
import socket, subprocess, sys, time, urllib.request

ip = sys.argv[1]
uport = int(sys.argv[2]) if len(sys.argv) > 2 else 7777
hport = int(sys.argv[3]) if len(sys.argv) > 3 else 8080
res = []

def rec(name, ok, info=""):
    res.append(ok); print(f"[{'PASS' if ok else 'FAIL'}] {name} {info}", flush=True)

try:
    cnt = "-n" if sys.platform.startswith("win") else "-c"
    r = subprocess.run(["ping", cnt, "3", ip], capture_output=True, text=True, timeout=30)
    rec("icmp ping", r.returncode == 0, (r.stdout.strip().splitlines() or [""])[-1])
except FileNotFoundError:
    print("[SKIP] icmp ping (no ping command on this machine)")

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(2)
ok = False; rtt = 0
for i in range(3):
    msg = f"probe-{i}-{time.time()}".encode(); t0 = time.time()
    try:
        s.sendto(msg, (ip, uport)); data, _ = s.recvfrom(2048)
        if data == msg: ok = True; rtt = (time.time() - t0) * 1000; break
    except socket.timeout:
        pass
rec("udp echo", ok, f"rtt={rtt:.1f} ms" if ok else "(no reply)")

try:
    body = urllib.request.urlopen(f"http://{ip}:{hport}/", timeout=5).read().decode(errors="replace").strip()
    rec("http get", "hello" in body, repr(body[:60]))
except Exception as e:
    rec("http get", False, str(e))

print("RESULT:", "ALL PASS" if all(res) else "FAILED")
sys.exit(0 if all(res) else 1)
