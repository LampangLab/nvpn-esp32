# Upload to GitHub (delete this file afterwards)

## With git (recommended)
```sh
cd nvpn-esp32
git init -b main
git add .
git commit -m "Initial release: nvpn-esp32"
git remote add origin https://github.com/LampangLab/nvpn-esp32.git
git push -u origin main
```
(use a personal access token or `gh auth login` when asked to sign in)

## With the web page
Open the repo → Add file → Upload files → drag the CONTENTS of the folder (not the folder itself and not the zip; GitHub does not unpack zips). Commit.
