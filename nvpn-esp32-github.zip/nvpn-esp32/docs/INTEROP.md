# Interop notes (for implementers of other small FIPS / nostr-vpn clients)

Status as of the versions below. This is an independent port; nothing here is endorsed by the nostr-vpn or FIPS projects.

## Versions

| Item | Version |
|---|---|
| nostr-vpn desktop app (hardware tests) | 4.1.19, `fips_core` 0.4.110 |
| Reference node used in the host tests | `nvpn-fips-core` 0.4.107 and 0.4.110 (built from the crates) |
| Specification read | `mmalmi/fips` `docs/design/fips-wire-formats.md` ("Client role negotiation") and `fips-mesh-operation.md` ("Client-Only Operation"), tag `fips-core-v0.4.108` |
| Hardware | one Arduino-ESP32 board, public seed `fips2.iris.to` |

## Client-only role (implemented)

1. On link-up the leaf sends `ClientSupport` (0x53, no payload) before any tree announcement.
2. When the upstream's tree bootstrap has arrived, the leaf allows one announcement interval (2 s) for the upstream's `ClientSupport`/`ClientOnly`.
3. If it answers: the leaf sends `ClientOnly` (0x52, u64 LE declaration sequence) **instead of** `TreeAnnounce`, and a Bloom filter holding only its own identity. The sequence is taken from the tree-sequence counter (seeded from the upstream's unix timestamp), so it advances past any earlier router declaration. It is repeated at the normal announcement cadence with the same sequence (the reference implementation accepts an equal sequence from a node that is already a client).
4. If it does not answer within the interval: fallback to the ordinary `TreeAnnounce` (parent = upstream) so a legacy upstream still reaches the leaf. A late `ClientSupport` switches the leaf to the client role.
5. The leaf never forwards, never offers itself as root or parent, answers only lookups for its own identity, and keeps its own coordinates ([self] + upstream ancestry) for lookup replies and sessions.

Tests (`test/client_role.sh`, loopback, real `nvpn-fips-core` nodes; all pass on 0.4.107 and 0.4.110): default → client-only + ping through the seed; negotiation disabled → TreeAnnounce + ping; upstream answer ignored → fallback after one interval + ping; peer-initiated session towards the client-only leaf.
Not tested: a genuinely legacy (pre-0.4.101) node, real hardware against `fips1/2.iris.to` (to be reported separately).

## Rekeys

The leaf answers peer-initiated FSP rekeys (SessionSetup → msg3 → pending epoch; cutover on the first authenticated frame with the other K bit; previous epoch drained for a fixed window). It **never initiates** a rekey, and it does **not** answer a peer-initiated FMP link rekey (an FMP `msg1` arriving on an established link is only counted and traced). Whether the public seeds ever start FMP rekeys towards a leaf is exactly what the trace below should show.

### Trace format (Arduino examples)

Every event prints one line; no keys or payloads are logged:

```
RK #<n> t=<sec.ms>s link_tx=<FMP frames sent> link_rx=<authenticated frames received> <event> arg=<x>
```

Events: `link-up`, `link-down`, `FMP msg1 rx` (peer starts a *link* rekey), `FMP K-flip` (link key epoch changed), `FSP SessionSetup rx`, `FSP msg3: new session`, `FSP msg3: REKEY` (pending epoch stored), `FSP cutover` (pending epoch promoted), `FSP dead-peer reset`, and role events (`ClientSupport tx/rx`, `ClientOnly tx`, `TreeAnnounce tx`, `fallback`). `RK status` every 30 s prints the role. The existing `DG …` line carries the counters (`aead`, `prom`, `deadreset`).

To attribute rekeys, compare the board's `RK` lines with the PC's `daemon.log` for the same wall-clock window (the board has no real-time clock in the trace; note the uptime at a known event such as `link-up`).

## Findings from the first hardware trace (board `jame` Wi-Fi, PC app 4.1.19 / core 0.4.110, seed `fips2.iris.to`, 15 min)

- `fips2.iris.to` did **not** answer `ClientSupport`; the leaf fell back to `TreeAnnounce` after one interval (`role=2` for the whole run). Whether the seed predates the client role or answers only under another condition is not known to us.
- No FMP event at all in 929 s: no peer `msg1`, no K-flip. Every rekey was an FSP rekey initiated by the PC, 15 of them, one every 59.9–60.0 s. They match the PC's `Unacknowledged session traffic exceeded recovery window; starting recovery rekey` lines 1:1 (not the configured timer).
- Cause (from reading `recover_unresponsive_sessions` and `has_unacknowledged_outbound_from` in core 0.4.110): with receiver reports enabled, the PC treats only an advancing session `ReceiverReport` (0x12), or a validated direct path, as delivery feedback; our leaf sent none, so any PC data unreported for 5 s triggered a recovery rekey. The leaf now sends a session `ReceiverReport` (counters, echoed timestamp, dwell; at most one per second per session, only after data arrived). The 66-byte body round-trips through the real `SessionReceiverReport` decoder (`test/rr_vector.c`), and host sessions against 0.4.107/0.4.110 keep working. Effect on the recovery rekeys is **not yet confirmed on hardware**.
- Second run with the `ReceiverReport` (898 s): the PC's recovery rekeys of the board fell from one per minute (15 in 15 min) to 4 in about 15 min on the PC log, and the board saw 1 pending-epoch rekey and 1 dead-peer reset instead of 15 rekeys. Some recovery rekeys remain; cause not yet known.
- The 91-byte "rejected" messages (about one per 10 s) are nostr-vpn application control frames sharing the message type used for IPv4: `NVPN-FIPS-CTRL\0` + `{"v":1,"frame":{"kind":"ping","network_id":"…","sent_at":N}}` (`fips_control.rs`, `FipsControlFrame::Ping`). The app treats the `Pong` as presence. The leaf now answers `Ping` with `Pong` (same `network_id` and `sent_at`, `replied_at` = unix time derived from the upstream's tree timestamps, monotonic). Verified on the host against a real core node that sends the same frame (`MODE=in` in `test/mesh3.sh`: 19 pings, 19 pongs); not yet seen by the desktop app on hardware. Other frame kinds are counted and ignored.

## Open items

- `JoinRequest` / `JoinRoster` / `JoinRosterAck` (stateful, over FIPS-TCP service port 7370; validate request binding, roster signature, admin/member identity and freshness, persist, then ack with the exact roster event id) — not implemented, so the app may show "waiting for this device to confirm".
- Phone-to-board across genuinely separate networks, reconnect behaviour and packet loss during rekey on hardware — not yet measured.
- Initiating rekeys / enforcing our own key-lifetime policy; MMP `SenderReport`s and link-layer reports.
