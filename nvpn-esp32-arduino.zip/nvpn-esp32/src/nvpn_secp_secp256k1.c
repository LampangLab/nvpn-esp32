/* generated: libsecp256k1 unit with MCU configuration */
#include "nvpn_secp_cfg.h"
#include "secp256k1/src/secp256k1.inc"
